/* @author Max
 */
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.function.Consumer;


public class TestClass extends Ship{

    public static void main(String[] args){
        ArrayList<Ship> list = new ArrayList<>();
        
        Ship ship1 = new Ship();
        Ship ship2 = new Ship("SS Poly", "1998");
        Ship cruiseShip1 = new CruiseShip();
        Ship cruiseShip2 = new CruiseShip("Carnival", "2005", 550);
        Ship cargoShip1 = new CargoShip();
        Ship cargoShip2 = new CargoShip("Bradley", "2008", 1150);
        
        list.add(ship1);
        list.add(ship2);
        list.add(cruiseShip1);
        list.add(cruiseShip2);
        list.add(cargoShip1);
        list.add(cargoShip2);
        
        list.forEach((Ship entry) -> {
            PrintStream printf = System.out.printf("Name = %\tYear = %s\n", entry.getShipName(), entry.getShipYear());
        });
                      
    }
}
