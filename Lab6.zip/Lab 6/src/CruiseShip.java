/* @author Max
 */
public class CruiseShip extends Ship {

        public int maxPassengers;
	
	public CruiseShip()
	{
		maxPassengers = 0;
	}
	
	public CruiseShip (String n, String y, int mp) 
	{
	   super(n,y);
	   maxPassengers = mp;
	}

	public int getMaxPassengers() {
		return maxPassengers;
	}

	public void setMaxPassengers(int maxPasangers) {
		this.maxPassengers = maxPasangers;
	}
	public String toString(){
		return "The ship's name is: " + getShipName() + " and the ship's max passengers is: " + getMaxPassengers() + " and the ship's year is: " + getShipYear();
	}
}

