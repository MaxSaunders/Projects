/* @author Max
 */
public class CargoShip extends Ship {
        
    public int cargoCapacity;
	
	public CargoShip()
	{
		cargoCapacity = 0;
	}
	
	public CargoShip (String n, String y, int cc) 
	{
	   super(n,y);
	   cargoCapacity = cc;
	}
	
	public int getCargoCapacity() {
		return cargoCapacity;
	}

	public void setCargoCapacity(int cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}

	public String toString(){
		return "The ship's name is: " + getShipName() + " and the ship's cargo capacity is: " + getCargoCapacity() + " and the ship's year is: " + getShipYear();
	}
}

