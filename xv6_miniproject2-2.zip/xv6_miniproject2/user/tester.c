// Do not modify this file. It will be replaced by the grading scripts
// when checking your project.

#include "types.h"
#include "stat.h"
#include "user.h"
#include "rand.h"

int
main(int argc, char *argv[])
{
  sgenrand(genrand());
  for(int i = 0; i < 10; i++)
  {
  int test = genrand();
  printf(1, "Process pid: %d\n", getpid());
  printf(1, "Total getpid() calls: %d\n", getpidcount());
  printf(1, "xD Random: %d\n", test);
  }

  exit();
}
