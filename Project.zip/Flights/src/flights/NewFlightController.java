/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Max
 */
public class NewFlightController{

   @FXML
    private TextField aTime;

    @FXML
    private TextField fNumber;
    
    @FXML
    private Button exitButton;

    @FXML
    private TextField availableSeats;

    @FXML
    private TextField destination;

    @FXML
    private TextField fDate;

    @FXML
    private TextField dTime;
    
    @FXML
    private Text title;

    @FXML
    private Button addFlightButton;

    @FXML
    private TextField dCity;

    @FXML
    void addFlight(ActionEvent event) throws FileNotFoundException, IOException {
        PrintWriter fw = null;
        //check for flights txt file
        
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("flights.txt", true))) {
            //print user input to flights file
        bw.write(fNumber.getText());
        bw.write("\t");
        bw.write(fDate.getText());
        bw.write("\t");
        bw.write(dTime.getText());
        bw.write("\t");
        bw.write(aTime.getText());
        bw.write("\t");
        bw.write(dCity.getText());
        bw.write("\t");
        bw.write(destination.getText());
        bw.write("\t");
        bw.write("70");
        bw.newLine();
        
        title.setText("Done");
        
        
    } catch (IOException e) {
        e.printStackTrace();
        fw.close();
        
    }
        
    try (BufferedWriter bw = new BufferedWriter(new PrintWriter(fNumber.getText() + ".txt"))){
        for(int i = 1; i <= 10 ; i++){
            bw.write(i + "\t A B   C D E   F G");
            bw.newLine();
        }
    }    
    }
    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
    }

    }

