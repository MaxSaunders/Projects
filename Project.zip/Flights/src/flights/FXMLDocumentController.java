/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class FXMLDocumentController {

    @FXML
    private Button seatMapButton;

    @FXML
    private Button reservationsAll;

    @FXML
    private Button exitButton;

    @FXML
    private Button reservationsOne;

    @FXML
    private Button reservationButton;

    @FXML
    private Button allFlightsButton;

    @FXML
    private Button flightButton;

    @FXML
    void openFlight(ActionEvent event) {
        //open window to create a flight
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NewFlight.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Add New Flight");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void openReservation(ActionEvent event) {
        //open window to add reservations
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("NewReservation.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Add New Reservation");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void openSeatMap(ActionEvent event) {
        //open window to display seat map
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SeatMap.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Seat Map");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void openAllFlights(ActionEvent event) {
        //open window for all flights
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ShowFlights.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("All Flights");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void openAllReservations(ActionEvent event) {
        //open window for all reservations
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ShowAllReservations.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("All Reservations");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void openOneReservations(ActionEvent event) {
        //open window for a single flights reservations
try{
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ShowReservationsOne.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Reservations");
        stage.setScene(new Scene(root1));
        stage.show();

    }  catch(Exception e){
        System.out.print("cant load window");
    }
    }

    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
    }
    }
 
    

