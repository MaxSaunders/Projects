package flights;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ShowReservationsOneController {

    @FXML
    private TextField fNumber;

    @FXML
    private TextArea textArea;
    
    @FXML
    private Button exitButton;
    
    @FXML
    void showReservations(ActionEvent event) throws FileNotFoundException, IOException {
        textArea.setText(" ");
        try{
            BufferedReader buf = new BufferedReader(new FileReader("reservations.txt"));
            ArrayList<String> words = new ArrayList<>();
            String lineJustFetched = null;
            String[] wordsArray;
            
            while(true){
                lineJustFetched = buf.readLine();
                if(lineJustFetched == null){  
                    break; 
                }else{
                    wordsArray = lineJustFetched.split("\t");
                    for(String each : wordsArray){
                        if(!"".equals(each)){
                            words.add(each);
                        }
                    }
                }
            }
            for(String str : words){
                if(str.contains(fNumber.getText())){
                    
                    textArea.appendText(str+"\n"); 
                }
            }
            buf.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
   
    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
    }
}
