/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class NewReservationController {

    @FXML
    private TextField name;

    @FXML
    private Button addButton;

    @FXML
    private TextField rowNumber;

    @FXML
    private TextField seatNumber;

    @FXML
    private Button exitButton;
    
    @FXML
    private Text title;

    @FXML
    private TextField flightNumber;

    @FXML
    private TextField idNumber;

    @FXML
    private TextArea textArea;

    @FXML
    private Button checkButton;

    @FXML
    void checkSeats(ActionEvent event) throws IOException{
        textArea.setText(" ");
        File x = new File(flightNumber.getText() + ".txt");
if(x.exists() && !x.isDirectory()) {
try (BufferedWriter bw = new BufferedWriter(new FileWriter(flightNumber.getText() + ".txt", true))){
        textArea.setText("");
        File file = new File(flightNumber.getText() + ".txt");
        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        //set seatmap to text area field
        while((st = br.readLine())!= null){
            textArea.appendText(st);
            textArea.appendText("\n");
    }
}

}
    
else{
    textArea.setText("Flight Doesn't Exist");
}}

    @FXML

    void addReservation(ActionEvent event) throws FileNotFoundException, IOException {
PrintWriter fw = null;
int x = Integer.valueOf(rowNumber.getText());
int z = 0;
String y = seatNumber.getText();
switch(y){
    case "a":
    case "A":
        z = 1;
        break;
    case "b":
    case "B": 
        z = 2;
        break;
    case "c":
    case "C":
        z = 3;
        break;
    case "d":
    case "D":
        z = 4;
        break;
    case "e":
    case "E":
        z = 5;
        break;
    case "f":
    case "F":
        z = 6;
        break;
    case "g":
    case "G":
        z = 7;
        break;
    default: textArea.appendText("Invalid Seat Option");
}

File f = new File(flightNumber.getText() + ".txt");
if(f.exists() && !f.isDirectory()) {
    // do something
//change seat
    Scanner sc = new Scanner(new BufferedReader(new FileReader(f)));
      
        String[][] myArray = new String[10][13];
    int line = 0;

    while (sc.hasNextLine()) {
        String data = sc.nextLine();
        String[] token = data.split(" ");
        for(int i = 0; i < token.length; i++) {
            
            myArray[line][i] = token[i];
            
            
        }

        System.out.println();
        line++;
    }
    
        String str = myArray[z][x];
        System.out.print(str);
            if(str.contains(seatNumber.getText())){
                myArray[x -1][z] = "X";
                for(int j = 0; j < 11; j++){
                    for(int n = 0; n < 13; n++){
                System.out.print(myArray[j][n]);
                    }}
                    System.out.print("PLEASE");
                    try (BufferedWriter bw = new BufferedWriter(new PrintWriter(flightNumber.getText() + ".txt"))){
                        for(int q = 0; q < myArray.length; q++){
                            for(int w = 0; w < 10; w++){
                                bw.write(myArray[q][w]);
                        }
                        }
            }
            }
            else{
                title.setText("Seat is already Taken");
                }
    

//check for reservations file
    try (BufferedWriter bw = new BufferedWriter(new FileWriter("reservations.txt", true))) {
        //write user input to reservations file
        bw.write(idNumber.getText());
        bw.write(" ");
        bw.write(name.getText());
        bw.write(" ");
        bw.write(rowNumber.getText());
        bw.write(seatNumber.getText());
        bw.write(" ");
        bw.write(flightNumber.getText());
        bw.newLine();
        title.setText("Done");
    } catch (IOException e) {
        e.printStackTrace();

    }
    }
else {
    title.setText("Flight Does Not Exist");
}
}
    
    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
    }

}
