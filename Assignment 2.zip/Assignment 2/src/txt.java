/* @author Max
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Paths;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class txt {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        //open clients.txt, output data to the file then close clients.txt
        try (Formatter output = new Formatter("numbers.txt")){
            Scanner input = new Scanner(System.in);
            System.out.printf("%s%n%s%n? ", "Enter integer results (1 - 5)", "Enter -1 to end input. ");
            int temp = 0;
            try {
                temp = input.nextInt();
            }
            catch (NoSuchElementException elementException){
                    System.err.println("Invalid input. Please try again. ");
                    input.nextLine();
            }
            while (temp != -1){
                try{
                    output.format("%d ", temp);
                }
                catch (NoSuchElementException elementException){
                    System.err.println("Invalid input. Please try again. ");
                    input.nextLine();
                }

                System.out.print("? ");
                temp = input.nextInt();
            }
        }
catch (SecurityException | FileNotFoundException | FormatterClosedException e){
            e.printStackTrace();
        }
    int x1 = 0;
    int x2 = 0;
    int x3 = 0;
    int x4 = 0;
    int x5 = 0;
 
    try(Scanner input = new Scanner(Paths.get("numbers.txt"))){

    while(input.hasNext()){
        int x = input.nextInt();
        if (x == 1){
            x1 = x1 + 1;
        }
        if (x == 2){
            x2 = x2 + 1;
        }
        if (x == 3){
            x3 = x3 + 1;
        } 
        if (x == 4){
            x4 = x4 + 1;
        }
        if (x == 5){
            x5 = x5 + 1;
        }

    }
    PrintStream out = new PrintStream(new File("output.txt"));

    out.format("%s   %s","Rating","Frequency\n");
    out.println("\n");
    out.format("%s %8s\n","1",x1);
    out.println("\n");
    out.format("%s %8s","2",x2);
    out.println("\n");
    out.format("%s %8s\n","3",x3);
    out.println("\n");
    out.format("%s %8s\n","4",x4);
    out.println("\n");
    out.format("%s %8s\n","5",x5);
    out.println("\n");

    }
    }
}