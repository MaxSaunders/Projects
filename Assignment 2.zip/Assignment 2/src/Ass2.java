/* @author Max
 */
import java.util.Scanner;
public class Ass2 {
public static void main(String args[])
   {
       // 2D array to store sales of a prodect by a salesperson
       double[][] sales = new double[4][5];
       int person = 0, product;
       double sale;
       Scanner scanner = new Scanner(System.in);
       System.out.print("Enter employee number (-1 to end): ");
           person = scanner.nextInt();
       while(person != -1)
       {
        if (person >= 1 && person < 5){
           System.out.print("Enter product number: ");
           product = scanner.nextInt();
           if(product >= 1 && product < 6){

           System.out.print("Enter sales amount: ");

            sales[person-1][product-1] += scanner.nextInt();

           }
           else{
               System.out.println("Invalid!");
           }
        }
           else{
               System.out.println("Invalid!");
           }
           System.out.print("Enter employee number (-1 to end): ");
           person = scanner.nextInt();
       }

       // Start print the data in tabular form
       // Columns represents Sales persons
       System.out.println("\n\t\tSalesPerson1\tSalesPerson2\tSalesPerson3\tSalesPerson4\tTotal Sales");
      
       // Loop for each product
       for(int j=0; j<5; j++)
       {
           // Print row heading as Product number
           System.out.print("Product"+(j+1));
           // initialize total value of that row to 0
           double row_total = 0;
           // loop for each sales person
           for(int i=0; i<4; i++)
           {
               // print the value of total sales of product i by sales person j
               System.out.print("\t\t"+sales[i][j]);
               // add the same to row_total
               row_total += sales[i][j];
           }
           // print row_total at the end of the row
           System.out.println("\t\t"+row_total);
       }
       // Print total sales heading for column totals
       System.out.print("Total Sales");
       // initialize totalSales to zero which is for storing total sales of all rows and columns
       double totalSales = 0;
       // for each sales person
       for(int i=0; i<4; i++)
       {
           // initialize column total to 0
           double col_total = 0;
           // for each product
           for(int j=0; j<5; j++)
               // add sales value to col_total
               col_total += sales[i][j];
          
           // Print column total
           System.out.print("\t\t"+col_total);
           // Add the column total to totaalSales
           totalSales += col_total;
       }
       // print total sales
       System.out.println("\t\t"+totalSales+"\n");
   }
}

