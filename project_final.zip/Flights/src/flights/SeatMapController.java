/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SeatMapController {

    @FXML
    private TextField fNumber;

    @FXML
    private Button exitButton;
    
    @FXML
    private TextArea textArea;

    @FXML
    void showMap(ActionEvent event) throws IOException {
        
        //check for flight txt file
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fNumber.getText() + ".txt", true))){
        textArea.setText("");
        File file = new File(fNumber.getText() + ".txt");
        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        //set seatmap to text area field
        while((st = br.readLine())!= null){
            textArea.appendText(st);
            textArea.appendText("\n");
    }
    }
    }
    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
}
}