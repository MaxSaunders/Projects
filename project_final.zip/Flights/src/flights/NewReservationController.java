/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class NewReservationController {

    @FXML
    private TextField name;

    @FXML
    private Button addButton;

    @FXML
    private TextField rowNumber;

    @FXML
    private TextField seatNumber;

    @FXML
    private Button exitButton;
    
    @FXML
    private Text title;

    @FXML
    private TextField flightNumber;

    @FXML
    private TextField idNumber;

    @FXML
    private TextArea textArea;

    @FXML
    private Button checkButton;

    @FXML
    void checkSeats(ActionEvent event) throws IOException{
try (BufferedWriter bw = new BufferedWriter(new FileWriter(flightNumber.getText() + ".txt", true))){
        textArea.setText("");
        File file = new File(flightNumber.getText() + ".txt");
        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        //set seatmap to text area field
        while((st = br.readLine())!= null){
            textArea.appendText(st);
            textArea.appendText("\n");
    }
}
    }

    @FXML

    void addReservation(ActionEvent event) {
PrintWriter fw = null;
String x = rowNumber.getText();
String y = seatNumber.getText();
File f = new File(flightNumber.getText() + ".txt");
if(f.exists() && !f.isDirectory()) {
    // do something


//check for reservations file
    try (BufferedWriter bw = new BufferedWriter(new FileWriter("reservations.txt", true))) {
        //write user input to reservations file
        bw.write(idNumber.getText());
        bw.write(" ");
        bw.write(name.getText());
        bw.write(" ");
        bw.write(rowNumber.getText());
        bw.write(seatNumber.getText());
        bw.write(" ");
        bw.write(flightNumber.getText());
        bw.newLine();
        title.setText("Done");
    } catch (IOException e) {
        e.printStackTrace();

    }
    }
else {
    title.setText("Flight Does Not Exist");
}
    }
    @FXML
    void Exit(ActionEvent event) {
  Stage stage = (Stage) exitButton.getScene().getWindow();
    // do what you have to do
        stage.close();
    }
}

