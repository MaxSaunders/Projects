#include "types.h"
#include "stat.h"
#include "pstat.h"
#include "user.h"

#define N 64

int mini2test(void){
  struct pstat p;
  int i;
  for(i=0;i<N;i++){
    p.inuse[i]=0;
    p.tickets[i]=0;
    p.pid[i]=0;
    p.ticks[i]=0;
  }
  int info = getpinfo(&p); //populates the table that is returned
  printf(2,"here is a list of every process\n");
  for(i=0;i<N;i++){
    printf(1,"Pid: %d InUse: %d Tickets: %d Ticks: %d\n", p.pid[i], p.inuse[i], p.tickets[i], p.ticks[i]);
  }
  return info;
}

int main(void){
  mini2test();
  exit();
}