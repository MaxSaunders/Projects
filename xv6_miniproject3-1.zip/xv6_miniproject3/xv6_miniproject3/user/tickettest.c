#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int main(int argc, char *argv[]){
  int i;
  int fork_res;
  printf(1, "Parent PID: %d\n",getpid());

  for(i=1;i<=3;i++)
  {
    fork_res = fork();
    if(fork_res == 0){
      for(;;){}
    }
  }
  for(i=1;i<=5;i++){
    fork_res = fork();
    if(fork_res == 0){
      setTickets(i*10);
      //child processes
      printf(1, "Child %d PID: %d\n", i, getpid());
      for(;;){}
    }
  }
  exit();
}
